#!/bin/bash 
sudo mkdir /usr/share/X-AIR-Edit
sudo cp * /usr/share/X-AIR-Edit
sudo cp X-AIR-Edit.desktop /usr/share/applications



